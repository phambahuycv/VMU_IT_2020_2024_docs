package com.example.baithi87726;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.RadialGradient;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Random;

public class DeNam87726 extends AppCompatActivity {
    private View view1;
    private View view2;
    private View view3;

    private void findViews(){
        view1 = findViewById(R.id.viw1);
        view2 = findViewById(R.id.viw2);
        view3 = findViewById(R.id.viw3);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_de_nam87726);
        findViews();
    }


    public void clickOne(View view) {
        
    }
    public void clickTwo(View view) {
        String[] color = {"FFFFFFOO","FFFF00FF","FF00FFFF"};
        Random random = new Random();
        for(int i=0;i<color.length;i++) {
            random.nextInt(i);
        }
        String result = random.toString();
        view2.setBackground(result);
    }

    public int f(int a, int b){
        int x=1;
        if(a<b){
            for(int i=a;i<b;i++){
                if(i%2!=0){
                    x+=i*i;
                }
            }
        }
        else{
            for(int i=b;i<a;i++){
                if(i%2==0){
                    x+=i*i;
                }
            }
        }
        return x;
    }
    public void save(View view) throws IOException {
        Random random = new Random();
        int a = random.nextInt(10);
        int b = random.nextInt(10);
        int result = f(a,b);
        Toast.makeText(this,"Tich cac so tu "+a+"^2 toi "+b+"^2 la: "+result,Toast.LENGTH_LONG).show();
        FileOutputStream outputStream = openFileOutput("denam",MODE_PRIVATE);
        OutputStreamWriter writer = new OutputStreamWriter(outputStream);
        writer.write(result+" "+a+" "+b);
        writer.close();
        outputStream.close();
    }
    public void load(View view) throws IOException {
        FileInputStream inputStream = openFileInput("denam");
        InputStreamReader reader = new InputStreamReader(inputStream);
        BufferedReader bufferedReader = new BufferedReader(reader);
        String line = bufferedReader.readLine();
        Toast.makeText(this,line,Toast.LENGTH_LONG).show();
        bufferedReader.close();
        reader.close();
        inputStream.close();
    }
}