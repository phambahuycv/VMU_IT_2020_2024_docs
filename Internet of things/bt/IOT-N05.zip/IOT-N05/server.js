var fs = require('fs');
var url = require('url');
var http = require('http');
var WebSocket = require('ws');
var mysql = require('mysql');

var temp = 0;
var tempError = 0;
// function gửi yêu cầu(response) từ phía server hoặc nhận yêu cầu (request) của client gửi lên
function requestHandler(request, response) {
    fs.readFile('./BTL.html', function(error, content) {
        response.writeHead(200, {
            'Content-Type': 'text/html'
        });
        response.end(content);
    });
}

// create http server
var server = http.createServer(requestHandler);
var ws = new WebSocket.Server({
    server
});

var clients = [];

function broadcast(socket, data) {
    console.log(clients.length);
    for (var i = 0; i < clients.length; i++) {
        if (clients[i] != socket) {
            clients[i].send(data);
        }
    }
}


// Kết nối đến MySQL
var con = mysql.createConnection({
    host:"localhost",
    user: "root",
    password: "Hieu83102@*##p28Ukg7X#",
    database: "cuatudong",
});

    con.connect(function(err){
        if(err) throw err;

        console.log("MySQL connected");

        var sql ="SELECT * FROM trangthaicua";

        con.query(sql,function(err,result){
            if(err)throw err;
        });

        ws.on('connection', function(socket, req) {

            console.log('Client connected');
            clients.push(socket);

            socket.on('message', function(message) {

                console.log('received: %s', message);
                broadcast(socket, message);
                if(message == "5" && temp == 0){
                    con.query("SELECT SLEEP(10)",function(err,result){
                        if(err)throw err;
                    });
                    con.query("INSERT INTO trangthaicua (trangthai) VALUES('open')",function(err,result){
                        if(err)throw err;
                        console.log('insert data successfully');                                                
                    });
                    
                    temp = 1;
                }
                else{
                    temp = 0;
                }
            });
            socket.on('close', function() {
                var index = clients.indexOf(socket);
                clients.splice(index, 1);
                console.log('disconnected');
            });           
        });
    });


server.listen(3000);
console.log('Server listening on port 3000');