use cuatudong
create table trangthaicua(
id int not null primary key AUTO_INCREMENT,
trangthai nvarchar(10),
ngaygio datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
);

SELECT SLEEP(5) insert into trangthaicua(trangthai)values('open') 

SELECT * FROM trangthaicua

drop table trangthaicua